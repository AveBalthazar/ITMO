package Interfaces;

import Objects.Character;
import Objects.TrapSystem;

public interface Catchable {
    void grab(Character c, TrapSystem trap);
}
