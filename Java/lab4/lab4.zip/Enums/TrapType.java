package Enums;

public enum TrapType {
    Honey,
    Nuts;
}
