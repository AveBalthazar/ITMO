package Enums;

public enum Gender {
    Male,
    Female,
    Third,
    Plural;
}